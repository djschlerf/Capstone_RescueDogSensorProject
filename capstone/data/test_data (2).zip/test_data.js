eqfeed_callback({"type":"FeatureCollection","features":[
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188602,2017-10-08 10:00:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188608,2017-10-08 10:01:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188613,2017-10-08 10:02:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188618,2017-10-08 10:03:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188623,2017-10-08 10:04:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188628,2017-10-08 10:05:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188633,2017-10-08 10:06:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188638,2017-10-08 10:07:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188644,2017-10-08 10:08:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188649,2017-10-08 10:09:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188654,2017-10-08 10:10:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact1.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188659,2017-10-08 10:11:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188666,2017-10-08 10:12:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact2.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188671,2017-10-08 10:13:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188679,2017-10-08 10:14:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188685,2017-10-08 10:15:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.18869,2017-10-08 10:16:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188695,2017-10-08 10:17:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.1887,2017-10-08 10:18:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188705,2017-10-08 10:19:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.18871,2017-10-08 10:20:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188715,2017-10-08 10:21:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact1.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188721,2017-10-08 10:22:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188728,2017-10-08 10:23:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188733,2017-10-08 10:24:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188738,2017-10-08 10:25:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact2.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188743,2017-10-08 10:26:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188751,2017-10-08 10:27:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188756,2017-10-08 10:28:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188762,2017-10-08 10:29:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188767,2017-10-08 10:30:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188772,2017-10-08 10:31:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188777,2017-10-08 10:32:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact1.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188782,2017-10-08 10:33:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188789,2017-10-08 10:34:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188794,2017-10-08 10:35:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.1888,2017-10-08 10:36:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188805,2017-10-08 10:37:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.18881,2017-10-08 10:38:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact2.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188815,2017-10-08 10:39:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188823,2017-10-08 10:40:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188828,2017-10-08 10:41:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188833,2017-10-08 10:42:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188839,2017-10-08 10:43:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact1.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188844,2017-10-08 10:44:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188851,2017-10-08 10:45:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188856,2017-10-08 10:46:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188861,2017-10-08 10:47:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188866,2017-10-08 10:48:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188871,2017-10-08 10:49:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188877,2017-10-08 10:50:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188882,2017-10-08 10:51:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact2.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188887,2017-10-08 10:52:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188895,2017-10-08 10:53:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.1889,2017-10-08 10:54:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_contact1.png","event":"Contact 1","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188905,2017-10-08 10:55:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_sound.png","event":"Sound","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188912,2017-10-08 10:56:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188918,2017-10-08 10:57:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188923,2017-10-08 10:58:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188928,2017-10-08 10:59:30.0]},"id":"Dog-1"},
,"geometry":{"type":"Point","coordinates":[61.188871,2017-10-08 10:49:30.0]},"id":"Dog-1"},
,"geometry":{"type":"Point","coordinates":[61.188871,2017-10-08 10:49:30.0]},"id":"Dog-1"},
,"geometry":{"type":"Point","coordinates":[61.188871,2017-10-08 10:49:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188871,2017-10-08 10:49:30.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[61.188871,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"},
{"type":"Feature","properties":{"place":"Disaster Area X","url":"http://students.uaa.alaska.edu/capstone/images/schlerf_paw.png","event":"Heartbeat","time":"0"}
,"geometry":{"type":"Point","coordinates":[62.888888,2017-12-21 10:30:45.0]},"id":"Dog-1"}]});
